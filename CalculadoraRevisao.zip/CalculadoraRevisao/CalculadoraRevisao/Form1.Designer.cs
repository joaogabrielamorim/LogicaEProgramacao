﻿namespace CalculadoraRevisao
{
    partial class FrmCalc
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtN1 = new System.Windows.Forms.TextBox();
            this.txtN2 = new System.Windows.Forms.TextBox();
            this.lblN1 = new System.Windows.Forms.Label();
            this.lblN2 = new System.Windows.Forms.Label();
            this.btnMais = new System.Windows.Forms.Button();
            this.btnDivisao = new System.Windows.Forms.Button();
            this.btnMenos = new System.Windows.Forms.Button();
            this.btnMulti = new System.Windows.Forms.Button();
            this.lblR1 = new System.Windows.Forms.Label();
            this.lblR2 = new System.Windows.Forms.Label();
            this.lblR3 = new System.Windows.Forms.Label();
            this.lblR4 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtN1
            // 
            this.txtN1.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.txtN1.Font = new System.Drawing.Font("Arial", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtN1.ForeColor = System.Drawing.Color.Red;
            this.txtN1.Location = new System.Drawing.Point(197, 220);
            this.txtN1.Name = "txtN1";
            this.txtN1.Size = new System.Drawing.Size(211, 41);
            this.txtN1.TabIndex = 0;
            this.txtN1.TextChanged += new System.EventHandler(this.txtN1_TextChanged);
            // 
            // txtN2
            // 
            this.txtN2.Font = new System.Drawing.Font("Arial", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtN2.ForeColor = System.Drawing.Color.Red;
            this.txtN2.Location = new System.Drawing.Point(197, 344);
            this.txtN2.Name = "txtN2";
            this.txtN2.Size = new System.Drawing.Size(211, 41);
            this.txtN2.TabIndex = 1;
            // 
            // lblN1
            // 
            this.lblN1.AutoSize = true;
            this.lblN1.BackColor = System.Drawing.Color.Black;
            this.lblN1.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblN1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblN1.Location = new System.Drawing.Point(192, 174);
            this.lblN1.Name = "lblN1";
            this.lblN1.Size = new System.Drawing.Size(123, 29);
            this.lblN1.TabIndex = 2;
            this.lblN1.Text = "Numero 1";
            // 
            // lblN2
            // 
            this.lblN2.AutoSize = true;
            this.lblN2.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblN2.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblN2.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblN2.Location = new System.Drawing.Point(192, 306);
            this.lblN2.Name = "lblN2";
            this.lblN2.Size = new System.Drawing.Size(116, 29);
            this.lblN2.TabIndex = 3;
            this.lblN2.Text = "Numero2";
            // 
            // btnMais
            // 
            this.btnMais.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMais.Location = new System.Drawing.Point(67, 449);
            this.btnMais.Name = "btnMais";
            this.btnMais.Size = new System.Drawing.Size(105, 50);
            this.btnMais.TabIndex = 4;
            this.btnMais.Text = "+";
            this.btnMais.UseVisualStyleBackColor = true;
            this.btnMais.Click += new System.EventHandler(this.btnMais_Click);
            // 
            // btnDivisao
            // 
            this.btnDivisao.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDivisao.Location = new System.Drawing.Point(431, 449);
            this.btnDivisao.Name = "btnDivisao";
            this.btnDivisao.Size = new System.Drawing.Size(105, 50);
            this.btnDivisao.TabIndex = 5;
            this.btnDivisao.Text = "/";
            this.btnDivisao.UseVisualStyleBackColor = true;
            this.btnDivisao.Click += new System.EventHandler(this.btnDivisao_Click);
            // 
            // btnMenos
            // 
            this.btnMenos.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMenos.Location = new System.Drawing.Point(187, 449);
            this.btnMenos.Name = "btnMenos";
            this.btnMenos.Size = new System.Drawing.Size(105, 50);
            this.btnMenos.TabIndex = 6;
            this.btnMenos.Text = "-";
            this.btnMenos.UseVisualStyleBackColor = true;
            this.btnMenos.Click += new System.EventHandler(this.btnMenos_Click);
            // 
            // btnMulti
            // 
            this.btnMulti.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMulti.Location = new System.Drawing.Point(308, 449);
            this.btnMulti.Name = "btnMulti";
            this.btnMulti.Size = new System.Drawing.Size(105, 50);
            this.btnMulti.TabIndex = 7;
            this.btnMulti.Text = "*";
            this.btnMulti.UseVisualStyleBackColor = true;
            this.btnMulti.Click += new System.EventHandler(this.btnMulti_Click);
            // 
            // lblR1
            // 
            this.lblR1.AutoSize = true;
            this.lblR1.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.lblR1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblR1.Location = new System.Drawing.Point(75, 523);
            this.lblR1.Name = "lblR1";
            this.lblR1.Size = new System.Drawing.Size(0, 31);
            this.lblR1.TabIndex = 8;
            // 
            // lblR2
            // 
            this.lblR2.AutoSize = true;
            this.lblR2.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblR2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblR2.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblR2.Location = new System.Drawing.Point(206, 512);
            this.lblR2.Name = "lblR2";
            this.lblR2.Size = new System.Drawing.Size(0, 31);
            this.lblR2.TabIndex = 9;
            // 
            // lblR3
            // 
            this.lblR3.AutoSize = true;
            this.lblR3.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblR3.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblR3.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblR3.Location = new System.Drawing.Point(330, 521);
            this.lblR3.Name = "lblR3";
            this.lblR3.Size = new System.Drawing.Size(0, 31);
            this.lblR3.TabIndex = 10;
            // 
            // lblR4
            // 
            this.lblR4.AutoSize = true;
            this.lblR4.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblR4.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblR4.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblR4.Location = new System.Drawing.Point(469, 523);
            this.lblR4.Name = "lblR4";
            this.lblR4.Size = new System.Drawing.Size(0, 31);
            this.lblR4.TabIndex = 11;
            // 
            // FrmCalc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Red;
            this.BackgroundImage = global::CalculadoraRevisao.Properties.Resources.mascote_do_flamengo_urubu_wallpaper_7276;
            this.ClientSize = new System.Drawing.Size(980, 680);
            this.Controls.Add(this.lblR4);
            this.Controls.Add(this.lblR3);
            this.Controls.Add(this.lblR2);
            this.Controls.Add(this.lblR1);
            this.Controls.Add(this.btnMulti);
            this.Controls.Add(this.btnMenos);
            this.Controls.Add(this.btnDivisao);
            this.Controls.Add(this.btnMais);
            this.Controls.Add(this.lblN2);
            this.Controls.Add(this.lblN1);
            this.Controls.Add(this.txtN2);
            this.Controls.Add(this.txtN1);
            this.Name = "FrmCalc";
            this.Text = "Calculadora";
            this.Load += new System.EventHandler(this.FrmCalc_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtN1;
        private System.Windows.Forms.TextBox txtN2;
        private System.Windows.Forms.Label lblN1;
        private System.Windows.Forms.Label lblN2;
        private System.Windows.Forms.Button btnMais;
        private System.Windows.Forms.Button btnDivisao;
        private System.Windows.Forms.Button btnMenos;
        private System.Windows.Forms.Button btnMulti;
        private System.Windows.Forms.Label lblR1;
        private System.Windows.Forms.Label lblR2;
        private System.Windows.Forms.Label lblR3;
        private System.Windows.Forms.Label lblR4;
    }
}


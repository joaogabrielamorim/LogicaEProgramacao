﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CalculadoraRevisao
{
    public partial class FrmCalc : Form
    {
        public FrmCalc()
        {
            InitializeComponent();
        }

        private void txtN1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnMais_Click(object sender, EventArgs e)
        {
            float N1, N2, R1;
            N1=float.Parse(txtN1.Text);
            N2=float.Parse(txtN2.Text);
            R1=N1 + N2;

            lblR1.Text = R1.ToString();

        }

        private void btnMenos_Click(object sender, EventArgs e)
        {
            float N1, N2, R2;
            N1=float.Parse(txtN1.Text);
            N2=float.Parse(txtN2.Text);
            R2 = N1 - N2;

            lblR2.Text = R2.ToString();

        }

        private void FrmCalc_Load(object sender, EventArgs e)
        {

        }

        private void btnMulti_Click(object sender, EventArgs e)
        {
            float N1, N2, R3;
            N1= float.Parse(txtN1.Text);
            N2 = float.Parse(txtN2.Text);
            R3 = N1 * N2;

            lblR3.Text = R3.ToString();

        }

        private void btnDivisao_Click(object sender, EventArgs e)
        {
            float N1, N2, R4;
            N1 = float.Parse(txtN1.Text);
            N2=float.Parse(txtN2.Text);
            R4 = N1 / N2;

            lblR4.Text = R4.ToString();

        }
    }
}

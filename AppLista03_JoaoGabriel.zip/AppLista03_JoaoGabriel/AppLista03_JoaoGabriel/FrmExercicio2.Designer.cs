﻿namespace AppLista03_JoaoGabriel
{
    partial class FrmExercicio2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblExercicio2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblExercicio2
            // 
            this.lblExercicio2.AutoSize = true;
            this.lblExercicio2.Font = new System.Drawing.Font("Arial", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblExercicio2.Location = new System.Drawing.Point(54, 60);
            this.lblExercicio2.Name = "lblExercicio2";
            this.lblExercicio2.Size = new System.Drawing.Size(159, 32);
            this.lblExercicio2.TabIndex = 1;
            this.lblExercicio2.Text = "Exercicio 2";
            this.lblExercicio2.Click += new System.EventHandler(this.lblExercicio1_Click);
            // 
            // FrmExercicio2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblExercicio2);
            this.Name = "FrmExercicio2";
            this.Text = "FrmExercicio2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblExercicio2;
    }
}